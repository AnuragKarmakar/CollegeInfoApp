package com.anurag.college_info_db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, "CollegeInfo.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table CollegeDetails(imageURL text, name text, rating text, location text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists CollegeDetails");
    }

    public Boolean addColleges( String imgurl, String name, String rating, String location) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("imageURL", imgurl);
        cv.put("name", name);
        cv.put("rating", rating);
        cv.put("location", location);

        Cursor cursor = db.rawQuery("Select * from CollegeDetails where name = ?", new String[]{name});

        long result = db.insert("CollegeDetails", null, cv);
            if (result == -1) {
                return false;
            } else {
                return true;
            }
    }
}
