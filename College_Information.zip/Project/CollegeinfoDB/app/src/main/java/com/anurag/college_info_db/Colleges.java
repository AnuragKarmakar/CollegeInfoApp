package com.anurag.college_info_db;

public class Colleges {
    private String cUrl;
    private String cName;
    private String cLocation;
    private String cRating;

    public String getcUrl() {
        return cUrl;
    }

    public String getcName() {
        return cName;
    }

    public String getcLocation() {
        return cLocation;
    }

    public String getcRating() {
        return cRating;
    }

    public Colleges(String cUrl, String cName, String cLocation, String cRating) {
        this.cUrl = cUrl;
        this.cName = cName;
        this.cLocation = cLocation;
        this.cRating = cRating;
    }

}
