package com.anurag.college_info_db;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {

    private final Context context;
    RecyclerView recyclerView;
    List<Colleges> collegesList;

    final View.OnClickListener onClickListener = new MyOnClickListener();

    @NonNull
    @Override
    public RecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.single_item, parent, false);

        view.setOnClickListener(onClickListener);
        ViewHolder viewHolder = new ViewHolder(view);


        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapter.ViewHolder holder, int position) {
        Colleges colleges = collegesList.get(position);
        holder.imgUrl.setText(colleges.getcUrl());
        holder.collegeName.setText(colleges.getcName());
        holder.collegeRating.setText(colleges.getcRating());
        holder.collegeLocation.setText(colleges.getcLocation());
    }

    @Override
    public int getItemCount() {
        return collegesList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        TextView imgUrl, collegeName, collegeLocation, collegeRating;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgUrl = itemView.findViewById(R.id.url);
            collegeName = itemView.findViewById(R.id.name);
            collegeLocation = itemView.findViewById(R.id.location);
            collegeRating = itemView.findViewById(R.id.rating);
        }
    }

    public RecyclerAdapter(Context context, List<Colleges> collegesList, RecyclerView recyclerView){
        this.collegesList = collegesList;
        this.recyclerView = recyclerView;
        this.context = context;
    }

    private class MyOnClickListener implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            int itemPosition = recyclerView.getChildLayoutPosition(v);
            String item = collegesList.get(itemPosition).getName();
            Toast.makeText(context, item, Toast.LENGTH_SHORT).show();
        }
    }
}
