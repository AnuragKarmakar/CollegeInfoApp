package com.anurag.college_information.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import com.anurag.college_information.R;

public class WebViewActivity extends AppCompatActivity {

    WebView webView;
    String collegeWebsite;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        setTitle("College Website");

        webView = findViewById(R.id.web_view);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        webView.setWebViewClient(new Callback());
        //webView.loadUrl("https://www.youtube.com/");

        Intent i = getIntent();
        collegeWebsite = i.getStringExtra("collegeWebsite");
        webView.loadUrl(collegeWebsite);

    }

    private class Callback extends WebViewClient {
        @Override
        public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
            return false;
        }
    }
}