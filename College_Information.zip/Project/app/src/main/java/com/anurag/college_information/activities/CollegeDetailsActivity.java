package com.anurag.college_information.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.anurag.college_information.R;
import com.squareup.picasso.Picasso;

public class CollegeDetailsActivity extends AppCompatActivity {

    Button btnApply, btnWebView;
    ImageView dCollegeImage;
    TextView dCollegeName, dCollegeRating, dCollegeLocation, dCollegeDesc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college_details);

        dCollegeImage = findViewById(R.id.details_college_image);
        dCollegeName = findViewById(R.id.details_college_name);
        dCollegeRating = findViewById(R.id.details_college_rating);
        dCollegeLocation = findViewById(R.id.details_college_location);
        dCollegeDesc = findViewById(R.id.college_description);

        btnApply = findViewById(R.id.btn_apply);
        btnWebView = findViewById(R.id.btn_web_view);

        Intent i = getIntent();
        String cn = i.getStringExtra("collegeName");
        String cr = i.getStringExtra("collegeRating");
        String ci = i.getStringExtra("collegeImage");
        String cl = i.getStringExtra("collegeLocation");
        String cd = i.getStringExtra("collegeDesc");
        String cw = i.getStringExtra("collegeWebsite");

        Picasso.get().load(ci).error(R.drawable.error).into(dCollegeImage);
        dCollegeName.setText(cn);
        dCollegeRating.setText(cr);
        dCollegeLocation.setText(cl);
        dCollegeDesc.setText(cd);


        btnApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "The institute will be notified, of your application", Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(), "The college will contact you, Thank you", Toast.LENGTH_LONG).show();
            }
        });

        btnWebView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cw.equals("") || cw.length() == 0) {
                    Toast.makeText(CollegeDetailsActivity.this, "College Website not found", Toast.LENGTH_SHORT).show();
                } else {
                    Intent i = new Intent(CollegeDetailsActivity.this, WebViewActivity.class);
                    i.putExtra("collegeWebsite", cw);
                    startActivity(i);
                }
            }
        });
    }

}