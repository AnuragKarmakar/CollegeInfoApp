package com.anurag.college_information.adapters;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.anurag.college_information.R;
import com.anurag.college_information.activities.CollegeDetailsActivity;
import com.anurag.college_information.models.ModelClass;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> implements Filterable {


    private List<ModelClass> collegeList;
    private List<ModelClass> collegeListAll;
    private RecyclerViewClickListener listener;
    AutoCompleteTextView autoCompleteTextView;

    List<String> imageUrl, collegeName, collegeLocation, collegeRating;


    public RecyclerAdapter(List<ModelClass> collegeList, RecyclerViewClickListener listener) {
        this.collegeList = collegeList;
        collegeListAll = new ArrayList<>(collegeList);
        this.listener = listener;

    }

    @NonNull
    @Override
    public RecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.college_list_single_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapter.ViewHolder holder, int position) {

        String imageLink = collegeList.get(position).getImageLink();
        //int img = collegeList.get(position).getCollegeImage();
        String cName = collegeList.get(position).getCollegeName();
        String cRating = collegeList.get(position).getCollegeRating().toString();
        String cLocation = collegeList.get(position).getLocation();
        Picasso.get().load(imageLink).into(holder.imageView);

        //holder.setData(img, cName, cRating);


        holder.setData(imageLink, cName, cLocation, cRating);

    }


    @Override
    public int getItemCount() {
        return collegeList.size();
    }

    @Override
    public Filter getFilter() {
        return filter;
    }

    Filter filter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            List<ModelClass> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(collegeListAll);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (ModelClass item : collegeListAll) {
                    if (item.getCollegeName().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            collegeList.clear();
            collegeList.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private ImageView imageView;
        private TextView collegeName, collegeRating, collegeLocation;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.college_image);
            collegeName = itemView.findViewById(R.id.college_name);
            collegeRating = itemView.findViewById(R.id.college_rating);
            collegeLocation = itemView.findViewById(R.id.college_location);

            itemView.setOnClickListener(this);

        }

        public void setData(String imageLink, String cName, String cLocation, String cRating) {

            //imageView.setImageResource(img);
            Picasso.get().load(imageLink).error(R.drawable.error).into(imageView);
            collegeName.setText(cName);
            collegeRating.setText(cRating);
            collegeLocation.setText(cLocation);


        }

        @Override
        public void onClick(View v) {
            listener.onClick(v, getAdapterPosition());

            Intent i = new Intent(v.getContext(), CollegeDetailsActivity.class);

            i.putExtra("collegeImage", collegeList.get(getAdapterPosition()).getImageLink());
            i.putExtra("collegeName", collegeList.get(getAdapterPosition()).getCollegeName());
            i.putExtra("collegeRating", collegeList.get(getAdapterPosition()).getCollegeRating().toString());
            i.putExtra("collegeLocation", collegeList.get(getAdapterPosition()).getLocation());
            i.putExtra("collegeDesc", collegeList.get(getAdapterPosition()).getCollegeDesc());
            i.putExtra("collegeWebsite",collegeList.get(getAdapterPosition()).getCollegeWebsite());

            v.getContext().startActivity(i);

        }

    }

    public interface RecyclerViewClickListener {
        void onClick(View v, int position);
    }
}
