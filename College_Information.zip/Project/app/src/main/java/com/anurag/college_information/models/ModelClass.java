package com.anurag.college_information.models;

import java.util.Comparator;

public class ModelClass implements Comparable {

    //private int collegeImage;
    private String collegeName, imageLink, location, collegeDesc, collegeWebsite;
    private Double collegeRating;

    //public ModelClass(int collegeImage, String collegeName, String collegeRating){

    public ModelClass(String imageLink, String collegeName, String location, Double collegeRating, String collegeDesc, String collegeWebsite) {
        //this.collegeImage = collegeImage;
        this.imageLink = imageLink;
        this.collegeName = collegeName;
        this.collegeRating = collegeRating;
        this.location = location;
        this.collegeDesc = collegeDesc;
        this.collegeWebsite = collegeWebsite;
    }

    public ModelClass() {

    }

    /*public int getCollegeImage() {
        return collegeImage;
    }*/

    public String getImageLink() {
        return imageLink;
    }

    public String getCollegeName() {
        return collegeName;
    }

    public Double getCollegeRating() {
        return collegeRating;
    }

    public String getLocation() {
        return location;
    }

    public String getCollegeDesc() {
        return collegeDesc;
    }

    public String getCollegeWebsite(){return collegeWebsite;}


    public static Comparator<ModelClass> sortNameAtoZ = new Comparator<ModelClass>() {
        @Override
        public int compare(ModelClass c1, ModelClass c2) {
            return c1.getCollegeName().compareTo(c2.getCollegeName());
        }
    };

    public static Comparator<ModelClass> sortNameZtoA = new Comparator<ModelClass>() {
        @Override
        public int compare(ModelClass c1, ModelClass c2) {
            return c2.getCollegeName().compareTo(c1.getCollegeName());
        }
    };


    public static Comparator<ModelClass> sortRatingHtoL = new Comparator<ModelClass>() {

        @Override
        public int compare(ModelClass c1, ModelClass c2) {
            if (c2.getCollegeRating() < c1.getCollegeRating()) return -1;
            if (c2.getCollegeRating() > c1.getCollegeRating()) return 1;
            return 0;
        }
    };

    public static Comparator<ModelClass> sortRatingLtoH = new Comparator<ModelClass>() {

        @Override
        public int compare(ModelClass c1, ModelClass c2) {
            if (c1.getCollegeRating() < c2.getCollegeRating()) return -1;
            if (c1.getCollegeRating() > c2.getCollegeRating()) return 1;
            return 0;
        }
    };

    public static Comparator<ModelClass> sortLocationAtoZ = new Comparator<ModelClass>() {
        @Override
        public int compare(ModelClass c1, ModelClass c2) {
            return c1.getLocation().compareTo(c2.getLocation());
        }
    };

    public static Comparator<ModelClass> sortLocationZtoA = new Comparator<ModelClass>() {
        @Override
        public int compare(ModelClass c1, ModelClass c2) {
            return c2.getLocation().compareTo(c1.getLocation());
        }
    };

    public int compareTo(Object o) {
        return 0;
    }
}

