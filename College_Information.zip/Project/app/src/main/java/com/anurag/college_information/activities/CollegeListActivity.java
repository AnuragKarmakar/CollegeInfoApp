package com.anurag.college_information.activities;

import static com.anurag.college_information.activities.CareerGoalActivity.SHARED_PREFS;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.anurag.college_information.R;
import com.anurag.college_information.adapters.RecyclerAdapter;
import com.anurag.college_information.models.ModelClass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollegeListActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    private RecyclerAdapter.RecyclerViewClickListener listener;

    //ListView collegeList;
    TextView collegeListTitle;
    Button courseChange;
    RecyclerView recyclerView;
    LinearLayoutManager LayoutManager;
    RecyclerAdapter recyclerAdapter;
    List<ModelClass> cList;

    String courseName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college_list);
        setTitle(getIntent().getStringExtra("Title").toUpperCase());


        collegeListTitle = findViewById(R.id.college_list_title);
        courseChange = findViewById(R.id.btn_change_course);

        collegeListTitle.setText(getIntent().getStringExtra("Title") + " Colleges");

        initData();
        initRecyclerView();
        SortData();
        //FilterByLocation();

        courseChange.setTransformationMethod(null);
        courseChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear();
                editor.apply();

                Intent i = new Intent(CollegeListActivity.this, CareerGoalActivity.class);
                startActivity(i);
                finish();

            }
        });

    }

    private void filterDataByLocation() {

    }

    private void SortData() {
        Spinner spinner;
        final String[] paths = {"item 1", "item 2", "item 3"};

        spinner = findViewById(R.id.sort_spinner);

        ArrayAdapter<CharSequence> sortAdapter = ArrayAdapter.createFromResource(this, R.array.sort, android.R.layout.simple_spinner_item);
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(sortAdapter);
        spinner.setOnItemSelectedListener(this);
    }

    private void initRecyclerView() {
        setOnClickListener();

        recyclerView = findViewById(R.id.recycler_view);
        LayoutManager = new LinearLayoutManager(this);
        LayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(LayoutManager);
        recyclerAdapter = new RecyclerAdapter(cList, listener);
        recyclerView.setAdapter(recyclerAdapter);
    }

    private void setOnClickListener() {
        listener = new RecyclerAdapter.RecyclerViewClickListener() {
            @Override
            public void onClick(View v, int position) {

            }
        };
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String filterMethod = parent.getItemAtPosition(position).toString();


        switch (filterMethod) {
            case "Name (A to Z)":
                Collections.sort(cList, ModelClass.sortNameAtoZ);
                Toast.makeText(this, "Sorted by Name: A to Z", Toast.LENGTH_SHORT).show();
                break;
            case "Name (Z to A)":
                Collections.sort(cList, ModelClass.sortNameZtoA);
                Toast.makeText(this, "Sorted by Name: Z to A", Toast.LENGTH_SHORT).show();
                break;
            case "Location (A to Z)":
                Collections.sort(cList, ModelClass.sortLocationAtoZ);
                Toast.makeText(this, "Sorted by Location: A to Z", Toast.LENGTH_SHORT).show();
                break;
            case "Location (Z to A)":
                Collections.sort(cList, ModelClass.sortLocationZtoA);
                Toast.makeText(this, "Sorted by Location: Z to A", Toast.LENGTH_SHORT).show();
                break;
            case "Rating (Highest to Lowest)":
                Collections.sort(cList, ModelClass.sortRatingHtoL);
                Toast.makeText(this, "Sorted by Ratings: Highest to Lowest Rating", Toast.LENGTH_SHORT).show();
                break;
            case "Rating (Lowest to Highest)":
                Collections.sort(cList, ModelClass.sortRatingLtoH);
                Toast.makeText(this, "Sorted by Ratings: Lowest to Highest Rating", Toast.LENGTH_SHORT).show();
                break;


        }
        recyclerView.setLayoutManager(LayoutManager);
        recyclerAdapter = new RecyclerAdapter(cList, listener);
        recyclerView.setAdapter(recyclerAdapter);

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.search_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setQueryHint("Search Colleges");

        searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                recyclerAdapter.getFilter().filter(newText);
                return false;
            }
        });

        return true;
    }

    private void initData() {
        cList = new ArrayList<>();
        courseName = getIntent().getStringExtra("Title");

        switch (courseName) {

            case "BE/BTech":
                cList.add(new ModelClass("https://images.static-collegedunia.com/public/college_data/images/campusimage/14352969241.jpg",
                        "IIT Bombay - Indian Institute Of Technology - [IITB]",
                        "Mumbai",
                        10.0,
                        "IIT Bombay was founded in 1958.[7] In 1961, the Parliament decreed IITs as Institutes of National Importance.[8] A committee formed by the Government of India recommended the establishment of four higher institutes of technology to set the direction for the development of technical education in the country in 1946. Planning began in 1957 and the first batch of 100 students was admitted in 1958.[8] Since its establishment in Powai, the institute has physically expanded to include more than 584 major buildings with a combined area of more than 2.2 square kilometers.\n" +
                                "\n" +
                                "IIT Bombay is known for its 4 Year, 5 Year & 2 Year programmes for which the entry is through the Joint Entrance Examination – Advanced and Graduate Aptitude Test in Engineering. It offers degrees such as: Bachelor of Technology, Four Year Bachelor of Science, Five Year Master of Science, Five Year IDDDP (Inter-Disciplinary Dual Degree Programme), 2 or 3 Year Master of Technology, and a few others. It also has a comprehensive graduate program offering doctoral degrees in Science, Technology, Engineering and Mathematics.[8] It currently has a total of 15 academic departments, 20 centres, a school of excellence and four interdisciplinary programs including a Management Program.\n" +
                                "\n" +
                                "The college also has a department dedicated to the study of public policy, the Centre for Policy Studies, which offers postgraduate (Master's in Public Policy), doctoral and postdoctoral level courses in public policy. The Centre has five primary research areas: digital societies, structural inequalities, environment, markets and governance, and technology and society.[9]",
                        "https://www.iitb.ac.in/"));
                cList.add(new ModelClass("https://images.static-collegedunia.com/public/college_data/images/campusimage/1479294300b-5.jpg",
                        "A.P. Shah College of Engineering",
                        "Thane",
                        8.0,
                        "",
                        "https://www.apsit.edu.in/home#"));
                cList.add(new ModelClass("https://images.shiksha.com/mediadata/images/1505387934php0zH9ZO.jpeg",
                        "Pillai College Of Enginering",
                        "Mumbai",
                        8.2,
                        "",
                        "https://www.pce.ac.in/"));
                cList.add(new ModelClass("https://images.shiksha.com/mediadata/images/1499418924phpOpG948.jpeg",
                        "K.J. Somaiya College Of Engineering",
                        "Mumbai",
                        8.0,
                        "",
                        "https://kjsce.somaiya.edu/en"));
                cList.add(new ModelClass("https://images.uniapply.com/uploads/college/image/500/4610/Don_Bosco_High_School_2088_Building_3_1.jpg",
                        "Don Bosco Institute Of Technology",
                        "Mumbai",
                        8.1,
                        "",
                        "https://www.dbit.in/"));
                cList.add(new ModelClass("https://static.toiimg.com/photo/77188989.cms",
                        "Xavier Institute Of Engineering",
                        "Mumbai",
                        4.8,
                        "",
                        "https://www.xavier.ac.in/"));
                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/1630755835SFITColegeBuilding2.jpg?mode=stretch",
                        "St. Francis Institute Of Technology",
                        "Mumbai",
                        4.9,
                        "",
                        "https://www.sfit.ac.in/"));
                cList.add(new ModelClass("https://akm-img-a-in.tosshub.com/indiatoday/images/story/202003/nmims.jpeg?1pB9jqjgItXTQpVNLYgKkF3ALp7wgGIH&size=770:433",
                        "Mukesh Patel School Of Technology Management & Engineering",
                        "Mumbai",
                        6.4,
                        "",
                        "https://engineering.nmims.edu/"));
                cList.add(new ModelClass("https://bvcoenm.edu.in/wp-content/uploads/2021/06/4-768x338.png",
                        "Bharti Vidyapeeth College Of Engineering",
                        "Mumbai",
                        4.6,
                        "",
                        "https://bvcoenm.edu.in/"));
                cList.add(new ModelClass("https://www.spit.ac.in/wp-content/uploads/2009/11/Entrance.jpg",
                        "Sardar Patel Institute Of Technology",
                        "Mumbai",
                        6.4,
                        "",
                        "https://www.spit.ac.in/"));
                cList.add(new ModelClass("https://www.prolineconsultancy.com/wp-content/uploads/2019/05/thakur-college-of-engineering-and-technology.jpg",
                        "Thakur College Of Engineering & Technology",
                        "Mumbai",
                        6.1,
                        "",
                        "https://www.tcetmumbai.in/"));
                cList.add(new ModelClass("https://www.microtec.in/storage/020d4b46-c616-4289-a08d-ba91b4bc3ae0/020d4b46-c616-4289-a08d-ba91b4bc3ae0-1588670564.jpeg",
                        "Vidyalankar Institute Of Technology",
                        "Mumbai",
                        8.4,
                        "",
                        "https://vit.edu.in/"));
                cList.add(new ModelClass("https://joinus4education.in/images/fc-engg-mum.jpg",
                        "Fr. Conceicao Rodrigues College Of Engineering",
                        "Mumbai",
                        4.9,
                        "",
                        "http://www.frcrce.ac.in/"));
                //cList.add(new ModelClass("", "", "Mumbai", ,"", ""));


                break;

            case "Pharmacy":
                cList.add(new ModelClass("https://images.static-collegedunia.com/public/college_data/images/campusimage/14382400753.jpg",
                        "Bombay College Of Pharmacy",
                        "Mumbai",
                        9.0,
                        "Bombay College of Pharmacy is one of the most leading and recognized pharmacy institutions in India. The institution was established in 1957 by the Indian Pharmaceutical Association Maharashtra State Branch (IPA-MSB) with financial assistance from the Government of Maharashtra and other pharmaceutical corporations. It offers bachelors, masters, doctorate and diploma courses to the students. BCP has generated more than 1500 Pharmacists and 300 M.Pharma and 170 Ph.D., graduates. The traveling expense is moderate as the college is just 2.5km away from both Santacruz and Kurla railway stations. The college ranked 24th in NIRF 2020.",
                        "https://www.bcp.edu.in/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/1505131397cover.jpg",
                        "Institute Of Chemical Technology - [ICT]",
                        "Mumbai",
                        8.6,
                        "",
                        "https://www.ictmumbai.edu.in/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/_LAW1.jpg",
                        "Shobhaben Pratapbhai Patel School of Pharmacy and Technology Management",
                        "Mumbai",
                        8.2,
                        "",
                        "https://pharmacy.nmims.edu/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/9781_P1.jpg",
                        "Poona College of Pharmacy (PCP)",
                        "Pune",
                        8.1,
                        "",
                        "https://pcp.bharatividyapeeth.edu/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/9386_DBNCP_APP.jpg",
                        "Dr. Bhanuben Nanavati College Of Pharmacy",
                        "Mumbai",
                        8.3,
                        "",
                        "https://bncp.ac.in/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/_11136651_346707688872453_7801850492282602340_n.jpg",
                        "VES College Of Pharmacy",
                        "Mumbai",
                        9.0,
                        "",
                        "https://vespharmacy.ves.ac.in/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/3716_RRC.jpg",
                        "Ramnarain Ruia Autonomous College",
                        "Mumbai",
                        7.9,
                        "Ramnarain Ruia Autonomous College was established in the year 1937 by the Shikshana Prasaraka Mandali, in Mumbai, Maharashtra. The college is recognized by UGC and affiliated to the University of Mumbai. It has been re-accredited with grade A by NAAC in 2017.",
                        "https://www.ruiacollege.edu/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/25724_SNDTWU_New.jpg",
                        "Shreemati Nathibai Damodar Thackersey [SNDT] Women’s University",
                        "Mumbai",
                        7.6,
                        "Shreemati Nathibai Damodar Thackersey [SNDT] Women’s University was established in 1916 and is the first Women’s University in India and South-East Asia. It is located in Mumbai, Maharashtra with having 166 affiliated colleges, spread over 3 campuses in 7 other states as well. The University has 15 faculties offering 117 courses - UG and PG Diploma, UG and PG Degrees, Research, and Doctorate degrees, across different streams",
                        "https://sndt.ac.in/"));


                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/10971_SGSMC_New.jpg",
                        "Seth GS Medical College - [GSMC]",
                        "Mumbai",
                        8.0,
                        "",
                        "https://www.kem.edu/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/16147721421.jpg",
                        "Narsee Monjee Institute of Management Studies",
                        "Mumbai",
                        8.2,
                        "NMIMS   is deemed to be a University owning 17 specialized schools, more than 17000 students, and 750 plus full-time faculty members. The College offers a vast array of PG and Doctoral programs in Management studies such as MBA, E-MBA, PGDM, PhD along with a few UG, Diploma, and PG diploma programs.  Known for its MBA/PGDM program, the NMIMS Mumbai is AICTE accredited and has been ranked 22 by NIRF in 2021 in management category.  NMIMS Mumbai programs are nationally and internationally accredited by NBA, NAAC, AMBA, SAQS and Bureau of Indian Standards. The Business School continues to attract applications in excess of 60,000 for a capacity of 860 MBA seats\n",
                        "https://www.nmims.edu/"));


                break;

            case "BSc":
                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/3716_RRC.jpg",
                        "Ramnarain Ruia Autonomous College",
                        "Mumbai",
                        7.9,
                        "Ramnarain Ruia Autonomous College was established in the year 1937 by the Shikshana Prasaraka Mandali, in Mumbai, Maharashtra. The college is recognized by UGC and affiliated to the University of Mumbai. It has been re-accredited with grade A by NAAC in 2017.",
                        "https://www.ruiacollege.edu/"));
                break;

            case "BArch":
                cList.add(new ModelClass("https://images.shiksha.com/mediadata/images/1505387934php0zH9ZO.jpeg",
                        "Pillai College Of Enginering",
                        "Mumbai",
                        8.2,
                        "",
                        "https://www.pce.ac.in/"));
                break;

            case "Commerce":
                cList.add(new ModelClass("https://images.static-collegedunia.com/public/college_data/images/campusimage/14193215742.jpg", "Kelkar Education Trust's V.G. Vaze College Of Arts Science And Commerce", "Mumbai", 9.0, "", ""));
                break;

            case "Arts":
                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/3716_RRC.jpg",
                        "Ramnarain Ruia Autonomous College",
                        "Mumbai",
                        7.9,
                        "Ramnarain Ruia Autonomous College was established in the year 1937 by the Shikshana Prasaraka Mandali, in Mumbai, Maharashtra. The college is recognized by UGC and affiliated to the University of Mumbai. It has been re-accredited with grade A by NAAC in 2017.",
                        "https://www.ruiacollege.edu/"));
                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/15717_DG_New.png",
                        "D.G. Ruparel College of Arts, Science and Commerce",
                        "Mumbai",
                        7.9,
                        "D.G. Ruparel College of Arts, Science and Commerce is a private leading college in Mumbai currently offering more than 30 programmes at the UG, PG and Research level in the fields of Humanities, Physical, Biological and Social Sciences, law, Technology, Management and Commerce. The popular and famous courses of D.G. Ruparel College includes B.A, B.Com and B.Sc which are offered under a variety of specializations. Admission to these popular programmes of D.G. Ruparel College of Arts, Science and Commerce is strictly done on the basis of the merits secured by the applicants in their 10+2 level board examination. Also, the college aims to create its students into successful professionals by providing them qualitative education with great professional exposure during their years of graduation",
                        "http://www.ruparel.edu/"));

                break;

            case "Science":
                cList.add(new ModelClass("https://images.static-collegedunia.com/public/college_data/images/campusimage/14193215742.jpg", "Kelkar Education Trust's V.G. Vaze College Of Arts Science And Commerce", "Mumbai", 9.0, "", ""));
                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/3716_RRC.jpg",
                        "Ramnarain Ruia Autonomous College",
                        "Mumbai",
                        7.9,
                        "Ramnarain Ruia Autonomous College was established in the year 1937 by the Shikshana Prasaraka Mandali, in Mumbai, Maharashtra. The college is recognized by UGC and affiliated to the University of Mumbai. It has been re-accredited with grade A by NAAC in 2017.",
                        "https://www.ruiacollege.edu/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/1504695740cover.jpg",
                        "St. Xavier’s College",
                        "Mumbai",
                        8.2,
                        "St. Xavier’s College in Mumbai is a private roman catholic college affiliated with the University of Mumbai. The college has been ranked as India’s No.1 private autonomous college 2021-22 by Education World for the second year in a row.",
                        "https://www.xaviers.edu/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/15717_DG_New.png",
                        "D.G. Ruparel College of Arts, Science and Commerce",
                        "Mumbai",
                        7.9,
                        "D.G. Ruparel College of Arts, Science and Commerce is a private leading college in Mumbai currently offering more than 30 programmes at the UG, PG and Research level in the fields of Humanities, Physical, Biological and Social Sciences, law, Technology, Management and Commerce. The popular and famous courses of D.G. Ruparel College includes B.A, B.Com and B.Sc which are offered under a variety of specializations. Admission to these popular programmes of D.G. Ruparel College of Arts, Science and Commerce is strictly done on the basis of the merits secured by the applicants in their 10+2 level board examination. Also, the college aims to create its students into successful professionals by providing them qualitative education with great professional exposure during their years of graduation",
                        "http://www.ruparel.edu/"));

                cList.add(new ModelClass("https://images.collegedunia.com/public/college_data/images/appImage/2229_1905859.jpg",
                        "KJ Somaiya College of Arts & Commerce",
                        "Mumbai",
                        8.1,
                        "KJSAC (KJ Somaiya College of Arts & Commerce) is one of the premier institutions that was established in the year 1959. The college is affiliated to the University of Mumbai and recognized by UGC. It has also been credited NAAC Grade “A” and has over 50 years of excellence.",
                        "https://kjsac.somaiya.edu.in/en"));

                break;

            case "MSc/MTech":
                cList.add(new ModelClass("https://images.static-collegedunia.com/public/college_data/images/campusimage/14352969241.jpg", "IIT Bombay - Indian Institute Of Technology - [IITB]", "Mumbai", 10.0, "", ""));
                break;

        }

    }
}